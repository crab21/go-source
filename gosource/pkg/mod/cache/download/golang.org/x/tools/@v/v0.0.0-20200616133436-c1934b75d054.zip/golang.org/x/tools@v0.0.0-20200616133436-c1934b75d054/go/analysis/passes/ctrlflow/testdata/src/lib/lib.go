package lib

func CanReturn() {}

func NoReturn() {
	for {
	}
}
